
/* * Authors: Courtney Richardson, James Hinshaw
 * 
 
package experiment;

import java.util.AbstractQueue;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

public class IntBoard {

	private BoardCell[][] grid;
	private Map<BoardCell, Set<BoardCell>> adjMtx;
	private Set<BoardCell> targets;
	private Set<BoardCell> visited;
	public IntBoard() {
		grid = new BoardCell[4][4];
		adjMtx = new HashMap<BoardCell, Set<BoardCell>>();
		for(int i = 0; i < 4; i++) {
			for(int j = 0; j < 4; j++) {
				BoardCell temp = new BoardCell();
				temp.col = j;
				temp.row = i;
				grid[i][j] = temp;
			}
		}
		
		calcAdjancencies();
		
	}
	
	public void calcAdjancencies() {
		for(int i = 0; i < 4; i++) {
			for(int j = 0; j < 4; j++) {
				Set<BoardCell> temp = new HashSet<BoardCell>();
				if((i-1) < 4 && (i-1) >= 0) {
					temp.add(grid[i-1][j]);
				}
				if((i+1) < 4 && (i+1) >= 0) {
					temp.add(grid[i+1][j]);
				}
				if((j-1) < 4 && (j-1) >= 0) {
					temp.add(grid[i][j-1]);
				}
				if((j+1) < 4 && (j+1) >= 0) {
					temp.add(grid[i][j+1]);
				}
				adjMtx.put(grid[i][j], temp);
			}
		}		
	}
		
	
	
	public Set<BoardCell> getAdjList(BoardCell aCell){
		return adjMtx.get(aCell);
	}
	
	public void findAllTargets( BoardCell aCell, int pathLeft) {
		Set<BoardCell> nextNodes = new HashSet<BoardCell>();
		nextNodes = getAdjList(aCell);
		
		for(BoardCell a: nextNodes) {
			if(visited.contains(a)) {
			}
			else {
				visited.add(a);
				if(pathLeft == 1) {
					targets.add(a);
				}
				else {
					findAllTargets(a, (pathLeft-1));
				}
			
			visited.remove(a);
			}
		}
		
	}
	
	public void calcTargets(BoardCell startCell, int pathLength) {
		visited = new HashSet<BoardCell>();
		targets = new HashSet<BoardCell>();
		visited.add(startCell);
		findAllTargets(startCell, pathLength);
		for (BoardCell p: targets) {
			System.out.println(p.row + " " + p.col);
		}
	}
	
	public Set<BoardCell> getTargets(){
		
		return targets;
	}

	public BoardCell getCell(int theRow, int theCol) {
		
		return grid[theRow][theCol];
	}
	
	
	
}*/
