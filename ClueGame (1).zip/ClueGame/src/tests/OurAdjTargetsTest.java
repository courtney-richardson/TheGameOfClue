/**
 * @author James Hinshaw and Courtney Richardson
 *
 */

package tests;

import static org.junit.Assert.*;

import java.io.IOException;
import java.util.Set;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import clueGame.BadConfigFormatException;
import clueGame.Board;
import clueGame.BoardCell;


/**
 * OurAdjTargetsTest class
 * Used to test adjacencies and targets functions and calculations
 *
 */
public class OurAdjTargetsTest {

	private static Board board;
	
	@BeforeClass
	public static void setUp() throws IOException, BadConfigFormatException {
		// Board is singleton, get the only instance
		board = Board.getInstance();
		// set the file names to use my config files
		board.setConfigFiles("BoardLayout.csv", "RoomNames.txt");		
		// Initialize will load BOTH config files 
		board.initialize();
	}
	
	
	/**
	 * Testing walkway scenarios
	 * Color is LIGHT PURPLE on spreadsheet
	 */
	@Test
	public void testAdjWalkways() {		// Locations with only walkways as adjacent locations
		
		Set<BoardCell> testList = board.getAdjList(11,12);	// location 11,12 on board
		assertTrue(testList.contains(board.getCellAt(11, 13)));
		assertTrue(testList.contains(board.getCellAt(11, 11)));
		assertTrue(testList.contains(board.getCellAt(12, 12)));
		assertTrue(testList.contains(board.getCellAt(10, 12)));
		assertEquals(4, testList.size());
	}
	
	/**
	 * Ensure that player does not move around within room
	 * Color is ORANGE on the spreadsheet
	 */
	@Test 
	public void testAdjRooms() {	// Locations within rooms
		
		Set<BoardCell> testList = board.getAdjList(2,16);	// location 2,16 on board
		assertEquals(0, testList.size());
	}
	
	
	/**
	 * Testing locations that are on the edge of the board
	 * Color is LIGHT GREEN on spreadsheet
	 */
	@Test
	public void testAdjEdgeLocations() {	// locations that are at each edge of the board
		//test left edge of board
		Set<BoardCell> testList = board.getAdjList(13,0);	// location at 13,0
		assertTrue(testList.contains(board.getCellAt(12, 0)));
		assertTrue(testList.contains(board.getCellAt(13, 1)));
		assertEquals(2, testList.size());
		
		//tests bottom edge of board
		testList = board.getAdjList(23,14);	// location at 23,14
		assertTrue(testList.contains(board.getCellAt(22, 14)));
		assertEquals(1, testList.size());
		
		//tests left edge of board
		testList = board.getAdjList(7,17);	// location at 7,17 
		assertTrue(testList.contains(board.getCellAt(7, 16)));
		assertEquals(1, testList.size());
		
		//tests top edge of board
		testList = board.getAdjList(0,6);	// location at 0,6 }
		assertTrue(testList.contains(board.getCellAt(0, 5)));
		assertTrue(testList.contains(board.getCellAt(1, 6)));
		assertEquals(2, testList.size());
	}
	
	/**
	 * Testing cells that are next to a room, but are not doorways
	 * Color is DARK BLUE on spreadsheet
	 */
	@Test
	public void testAdjNextToRoomNotDoor() {	// locations that are beside a room cell that is not a doorway
		
		
		Set<BoardCell> testList = board.getAdjList(5,13);	// location at 5, 13
		assertTrue(testList.contains(board.getCellAt(6, 13)));
		assertTrue(testList.contains(board.getCellAt(5, 12)));
		assertEquals(2, testList.size());
		
		
		testList = board.getAdjList(15, 17);	// location at 15,17
		assertTrue(testList.contains(board.getCellAt(15, 16)));
		assertEquals(1, testList.size());
	}
	
	
	/**
	 * Test locations that are adjacent to a doorway with a needed direction
	 * Color is GOLD (dark yellow) on the spreadsheet
	 */
	@Test
	public void testAdjIntoDoorways() {		// locations that are adjacent to a doorway with needed direction
		//test right door direction
		Set<BoardCell> testList = board.getAdjList(3,5);	// location at 3, 5
		assertTrue(testList.contains(board.getCellAt(3, 4)));
		assertTrue(testList.contains(board.getCellAt(3, 6)));	
		assertTrue(testList.contains(board.getCellAt(2, 5)));
		assertTrue(testList.contains(board.getCellAt(4, 5)));
		assertEquals(4, testList.size());
		
		//test left door direction
		testList = board.getAdjList(11,14);	// location at 11, 14
		assertTrue(testList.contains(board.getCellAt(11, 15)));
		assertTrue(testList.contains(board.getCellAt(11, 13)));	
		assertTrue(testList.contains(board.getCellAt(10, 14)));
		assertTrue(testList.contains(board.getCellAt(12, 14)));
		assertEquals(4, testList.size());
		
		//test down door direction
		testList = board.getAdjList(4,9);	// location at 4, 9
		assertTrue(testList.contains(board.getCellAt(4, 8)));
		assertTrue(testList.contains(board.getCellAt(4, 10)));	
		assertTrue(testList.contains(board.getCellAt(3, 9)));
		assertTrue(testList.contains(board.getCellAt(5, 9)));
		assertEquals(4, testList.size());
		
		//test up door direction
		testList = board.getAdjList(20,12);	// location at 20, 12
		assertTrue(testList.contains(board.getCellAt(21, 12)));
		assertTrue(testList.contains(board.getCellAt(19, 12)));	
		assertTrue(testList.contains(board.getCellAt(20, 11)));
		assertTrue(testList.contains(board.getCellAt(20, 13)));
		assertEquals(4, testList.size());
	}
	
	/**
	 * Testing locations that are doorways that have only one adjacent cell
	 * Color is RED on the spreadsheet
	 */
	@Test
	public void testAdjDoorways() {	// Locations that are doorways should have only one adjacent cell
		
		Set<BoardCell> testList = board.getAdjList(10,2);	// location at 10,2
		assertTrue(testList.contains(board.getCellAt(10, 3)));
		assertEquals(1, testList.size());
		
		testList = board.getAdjList(21,9);	// location at 3, 5
		assertTrue(testList.contains(board.getCellAt(20, 9)));
		assertEquals(1, testList.size());
	}
	
	/**
	 * Testing targets along walkways at various distances
	 * Color is DARK GREEN on spreadsheet
	 */
	@Test
	public void testTargetsWalkways() {	
		//moving one space starting at 17,5
		board.calcTargets(17,5,1);
		Set<BoardCell> testTargets = board.getTargets();	
		assertTrue(testTargets.contains(board.getCellAt(17, 4)));
		assertTrue(testTargets.contains(board.getCellAt(17, 6)));	
		assertTrue(testTargets.contains(board.getCellAt(16, 5)));
		assertTrue(testTargets.contains(board.getCellAt(18, 5)));
		assertEquals(4, testTargets.size());
		
		//moving two spaces starting at 4,11
		board.calcTargets(4,11,2);
		testTargets = board.getTargets();	
		assertTrue(testTargets.contains(board.getCellAt(3, 12)));
		assertTrue(testTargets.contains(board.getCellAt(5, 12)));	
		assertTrue(testTargets.contains(board.getCellAt(6, 11)));
		assertTrue(testTargets.contains(board.getCellAt(4, 9)));
		assertTrue(testTargets.contains(board.getCellAt(5, 10)));
		assertEquals(5, testTargets.size());
		
		//moving three spaces starting at 9,6
		board.calcTargets(9,6,3);
		testTargets = board.getTargets();	
		assertTrue(testTargets.contains(board.getCellAt(6, 6)));
		assertTrue(testTargets.contains(board.getCellAt(7, 7)));	
		assertTrue(testTargets.contains(board.getCellAt(9, 3)));
		assertTrue(testTargets.contains(board.getCellAt(10, 4)));
		assertTrue(testTargets.contains(board.getCellAt(8, 4)));
		assertTrue(testTargets.contains(board.getCellAt(7, 5)));
		assertTrue(testTargets.contains(board.getCellAt(9, 5)));
		assertTrue(testTargets.contains(board.getCellAt(8, 6)));
		assertEquals(8, testTargets.size());
		
		//moving two spaces starting at 9,0
		board.calcTargets(9,0,2);
		testTargets = board.getTargets();	
		assertTrue(testTargets.contains(board.getCellAt(9, 2)));
		assertEquals(1, testTargets.size());
	}
	
	/**
	 * Testing targets that allow user to enter a room
	 * Color is ORANGE on spreadsheet
	 */
	@Test
	public void testTargestDoors() {
		//moving one space starting at 0,13
		board.calcTargets(0,13,1);
		Set<BoardCell> testTargets = board.getTargets();	
		assertTrue(testTargets.contains(board.getCellAt(0, 12)));
		assertTrue(testTargets.contains(board.getCellAt(1, 13)));	
		assertEquals(2, testTargets.size());
		
		//moving two spaces starting at 5,9
		board.calcTargets(5,9,2);
		testTargets = board.getTargets();
		assertTrue(testTargets.contains(board.getCellAt(3, 9)));
		assertTrue(testTargets.contains(board.getCellAt(7, 9)));
		assertTrue(testTargets.contains(board.getCellAt(5, 11)));
		assertTrue(testTargets.contains(board.getCellAt(5, 7)));
		assertTrue(testTargets.contains(board.getCellAt(4, 8)));
		assertTrue(testTargets.contains(board.getCellAt(4, 10)));
		assertTrue(testTargets.contains(board.getCellAt(6, 10)));
		assertTrue(testTargets.contains(board.getCellAt(6, 8)));
		assertEquals(8, testTargets.size());
		
		//moving three spaces starting at 2,5
		//can enter a room without using all moving spaces
		board.calcTargets(2,5,3);
		testTargets = board.getTargets();
		assertTrue(testTargets.contains(board.getCellAt(3, 4)));
		assertTrue(testTargets.contains(board.getCellAt(0, 6)));
		assertTrue(testTargets.contains(board.getCellAt(2, 6)));
		assertTrue(testTargets.contains(board.getCellAt(4, 6)));
		assertTrue(testTargets.contains(board.getCellAt(3, 7)));
		assertTrue(testTargets.contains(board.getCellAt(4, 4)));
		assertTrue(testTargets.contains(board.getCellAt(5, 5)));
		assertTrue(testTargets.contains(board.getCellAt(3, 5)));
		assertTrue(testTargets.contains(board.getCellAt(1, 5)));
		assertEquals(9, testTargets.size());
	}
	
	
	/**
	 * Testing targets calculated when leaving a room
	 * Color is PINK on the spreadsheet
	 */
	@Test
	public void testTargetsLeavingRoom() {		// Targets calculated when leaving a room
		
		//moving two spaces starting at the doorway at 16,15
		board.calcTargets(16,15,2);
		Set<BoardCell> testTargets = board.getTargets();	
		assertTrue(testTargets.contains(board.getCellAt(16, 13)));
		assertTrue(testTargets.contains(board.getCellAt(17, 14)));
		assertTrue(testTargets.contains(board.getCellAt(15, 14)));
		assertEquals(3, testTargets.size());
		
		//moving two spaces starting at the doorway at 21,6
		board.calcTargets(21,6,2);
		testTargets = board.getTargets();
		assertTrue(testTargets.contains(board.getCellAt(20, 5)));
		assertTrue(testTargets.contains(board.getCellAt(20, 7)));
		assertTrue(testTargets.contains(board.getCellAt(19, 6)));
		assertEquals(3, testTargets.size());
		
		
	}

}
