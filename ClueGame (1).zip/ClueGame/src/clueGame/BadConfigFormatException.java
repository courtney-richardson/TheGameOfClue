/**
 *  @author Courtney Richardson & James Hinshaw
 * 
 */

package clueGame;

/**
 * Exception that is used when the format of the board does not meet expectations
 *
 */
public class BadConfigFormatException extends Exception {

	public BadConfigFormatException() {
		// Error that is thrown
		super("Error: CSV Format incorrect");
		
	}
	
	// String that prints out to let the user know details of the problem
	public BadConfigFormatException(String aString) {
		System.out.println("The cell intial " + aString + " is not found in the legend or uses the wrong door direction extensions");
		System.exit(0);
	}
	
	
}
