/** 
 * Authors: Courtney Richardson, James Hinshaw
 * 
 */

package clueGame;

public enum DoorDirection {
	RIGHT, LEFT, DOWN, UP, NONE;
}
