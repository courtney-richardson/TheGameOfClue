/** 
 * Authors: Courtney Richardson, James Hinshaw
 * 
 */

package clueGame;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javafx.util.Pair;

/**
 * Board Class
 * Sets up the board based on the csv file provided to the code
 * Contains the number of rows and columns in the board
 * Contains the legend - used to make sure every board cell is defined correctly
 * Sets up adjacency matrix - used when the player moves from cell to cell based on their number of moves
 *
 */

public class Board {

	private final static int MAX_BOARD_SIZE = 50;
	private static Board singleton_board = null;
	private String boardConfig;
	private String legendConfig;
	private Map<Character, String> legend; 
	private BoardCell[][] grid;
	private int numRows;
	private int numCols;
	
	private Map<BoardCell, Set<BoardCell>> adjMtx;
	private Set<BoardCell> targets;
	private Set<BoardCell> visited;
	
	
	
	/**
	 * @return the board
	 * Creates a board that is used for the game
	 */
	public static Board getInstance() {
		if (singleton_board == null) {
			singleton_board = new Board();
		}
		return singleton_board ;
	}

	/**
	 * @param string - used to create the board configuration
	 * @param string2 - used to create the legend configuration
	 */
	public void setConfigFiles(String string, String string2) {
		boardConfig = string;
		legendConfig = string2;
	}

	/**
	 * @return the legend for the board
	 * Used to test each board cell, ensuring that they are all labeled properly
	 */
	public Map<Character, String> getLegend() {
		return legend;
	}

	/**
	 * @return the number of rows of the imported board
	 */
	public int getNumRows() {
		return numRows;
	}

	/**
	 * @return the number of columns of the imported board
	 */
	public int getNumColumns() {
		return numCols;
	}

	/**
	 * Function used to call a specific board cell
	 */
	public BoardCell getCellAt(int i, int j) {
		return grid[i][j];
	}

	/**
	 * @throws IOException
	 * @throws BadConfigFormatException
	 * Function that initializes the board
	 * Creates the adjacency matrix, target cells, and visited cells
	 */
	public void initialize() throws IOException, BadConfigFormatException {
		// Read in Legend to Map
		adjMtx = new HashMap<BoardCell, Set<BoardCell>>();
		targets = new HashSet<BoardCell>();
		visited = new HashSet<BoardCell>();
		legend = new HashMap<Character, String>();
		
		loadRoomConfig();
		loadBoardConfig();
		calcAdjancencies();	
	}

	/**
	 * @throws IOException
	 * Function that reads the file and puts into the legend the letter that represents
	 * each room and the corresponding room name
	 */
	public void loadRoomConfig() throws IOException {
		
		String line = "";
		FileReader readFile = new FileReader(legendConfig);
		BufferedReader bufferedReader = new BufferedReader(readFile);
		
		while((line = bufferedReader.readLine()) != null) {
			String[] arrStr = line.split(", ", 0);
			char roomInitial = line.charAt(0);
			String roomName = arrStr[1];
			legend.put(roomInitial, roomName);
		}
	}

	/**
	 * @throws IOException
	 * @throws BadConfigFormatException
	 * Function that loads the board configuration
	 * 	Creates the board grid
	 * 	Checks each room initial to ensure that it is in the legend
	 * 	Throws an error if the room initial is not found in the legend
	 */
	public void loadBoardConfig() throws IOException, BadConfigFormatException {
			// Read in BoardLayout to Grid and find size of grid
			
			String line = "";
			FileReader readFile = new FileReader(legendConfig);
			BufferedReader bufferedReader = new BufferedReader(readFile);
	
			readFile = new FileReader(boardConfig);
			bufferedReader = new BufferedReader(readFile);
			int totalRows = 0;
			int totalColumns = 0;
			line = bufferedReader.readLine();
			totalRows++;
			String[] arr = line.split(",",  0);
			numCols = arr.length;
			while((line = bufferedReader.readLine()) != null) {
				arr = line.split(",",  0);
				totalColumns = arr.length;
				if(numCols != totalColumns) {
					throw new BadConfigFormatException();
				}
				totalRows++;
			} 
			
			numRows = totalRows;
			
			// Create the Board Grid
			grid = new BoardCell[totalRows][totalColumns];
			
			readFile = new FileReader(boardConfig);
			bufferedReader = new BufferedReader(readFile);
			
			for(int i = 0; i < numRows; i++) {
				line = bufferedReader.readLine();
				String[] arrayString = line.split(",",0);
				for(int j = 0; j < numCols; j++) {
					BoardCell temp = new BoardCell();
					temp.setRow(i);
					temp.setCol(j);
					temp.setRoomInitial(arrayString[j].charAt(0));
					System.out.println(arrayString[j]);
					if(arrayString[j].length() == 2) {
						temp.setDoorDirection(arrayString[j].charAt(1));
					}
					// Check if the room initial matches a character in the legend
					boolean isChar = false;
					for(char p: legend.keySet()) {			
						if(temp.getInitial() == p) {
							isChar = true;
							break;
						}
					}
					// if the room initial doesn't match, then throw an error
					if(!isChar) {		
						throw new BadConfigFormatException("The room initial: " + temp.getInitial() + " is not listed in the legend.");
					}
					grid[i][j] = temp;
				}
				
			}
	}

	/**
	 * @return the adjacency matrix
	 */
	public Set<BoardCell> getAdjList(int i, int j) {
		return adjMtx.get(grid[i][j]);
	}

	/**
	 * Function used to calculate the adjancencies of each board cell
	 * Determine if the board cell is a doorway, and from which direction the door can
	 * be entered from.
	 */
	public void calcAdjancencies() {
		for(int i = 0; i < numRows; i++) {
			for(int j = 0; j < numCols; j++) {
				Set<BoardCell> temp = new HashSet<BoardCell>();
				if(grid[i][j].getInitial() == 'W') {		// If cell is in  walkway
					if((j-1) < numCols && (j-1) >= 0) {
						if (grid[i][j-1].getInitial() == 'W' || grid[i][j-1].getDoorDirection() == DoorDirection.RIGHT) {
							temp.add(grid[i][j-1]);
						}
					}
					if((j+1) < numCols && (j+1) >= 0) {
						if (grid[i][j+1].getInitial() == 'W' || grid[i][j+1].getDoorDirection() == DoorDirection.LEFT) {
							temp.add(grid[i][j+1]);
						}
					}
					if((i-1) < numRows && (i-1) >= 0) {
						if (grid[i-1][j].getInitial() == 'W' || grid[i-1][j].getDoorDirection() == DoorDirection.DOWN) {
							temp.add(grid[i-1][j]);
						}
					}
					if((i+1) < numRows && (i+1) >= 0) {
						if (grid[i+1][j].getInitial() == 'W' || grid[i+1][j].getDoorDirection() == DoorDirection.UP) {
							temp.add(grid[i+1][j]);
						}
					}
				}
				else {
					switch((DoorDirection)grid[i][j].getDoorDirection()) {
						case LEFT:
							temp.add(grid[i][j-1]);
							break;
						case RIGHT:
							temp.add(grid[i][j+1]);
							break;
						case DOWN:
							temp.add(grid[i+1][j]);
							break;
						case UP:
							temp.add(grid[i-1][j]);
							break;
						default:
							break;
						}
				}
				adjMtx.put(grid[i][j], temp);
			}
		}	
		
	}
	
	/**
	 * @return the target cells
	 */
	public Set<BoardCell> getTargets() {
		return targets;
	}

	/**
	 * @param aCell
	 * @param pathLeft
	 * Helps to find a path that the player can take based on adjacent cells, doorway
	 * cells, and visited/target cells
	 */
	public void findAllTargets( BoardCell aCell, int pathLeft) {
		Set<BoardCell> nextNodes = new HashSet<BoardCell>();
		nextNodes = getAdjList(aCell.getRow(), aCell.getCol());
		
		for(BoardCell a: nextNodes) {
			if(visited.contains(a)) {
			}
			else {
				visited.add(a);
				if(pathLeft == 1 || a.isDoorway() == true) {
					targets.add(a);
				}
				else {
					findAllTargets(a, (pathLeft-1));
				}
			
			visited.remove(a);
			}
		}
	}
	
	/**
	 * Function used to calculate targets
	 * Makes call to findAllTargets function
	 */
	public void calcTargets(int i, int j, int k) {
		visited = new HashSet<BoardCell>();
		targets = new HashSet<BoardCell>();
		visited.add(grid[i][j]);
		findAllTargets(grid[i][j], k);
	}
}
