/** 
 * Authors: Courtney Richardson, James Hinshaw
 * 
 */

package clueGame;

/**
 * BoardCell class
 * Used to create the board cells
 * Used to return the number of board cells (row/col)
 * Used to get if the cell is a door, the door direction, and the room initial
 *
 */
public class BoardCell {

	private int row;
	private int col;
	private char roomInitial;
	private DoorDirection doorDirection;
	
	public BoardCell() {
		doorDirection = DoorDirection.NONE; // door direction should be preset to none if it does not exist
	}
	
	public int getRow() {
		return row;
	}
	
	public int getCol() {
		return col;
	}
	
	public char getInitial() {
		return roomInitial;
	}
	
	public DoorDirection getDoorDirection() {
		return doorDirection;
	}
	
	public void setRow(int aNum) {
		row = aNum;
	}
	
	public void setCol(int aNum) {
		col = aNum;
	}
	
	public void setRoomInitial(char anInitial) {
		roomInitial = anInitial;
	}
	
	public void setDoorDirection(char aChar) {	// Revise this later

		switch(aChar) {
		case 'D': 
			doorDirection = DoorDirection.DOWN;
			break;
		case 'U':
			doorDirection = DoorDirection.UP;
			break;
		case 'L':
			doorDirection = DoorDirection.LEFT;
			break;
		case 'R':
			doorDirection = DoorDirection.RIGHT;
			break;
		default:
			doorDirection = DoorDirection.NONE;
		}
	}
	
	public boolean isDoorway() {
		if (doorDirection.equals(DoorDirection.DOWN) || doorDirection.equals(DoorDirection.UP) || doorDirection.equals(DoorDirection.LEFT) || doorDirection.equals(DoorDirection.RIGHT)) {
			return true;
		}
		else {
			return false;
		}
	}

	
}
